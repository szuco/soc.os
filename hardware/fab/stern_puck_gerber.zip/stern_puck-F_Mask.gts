%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-20T09:48:50+02:00*%
%TF.ProjectId,stern_puck,73746572-6e5f-4707-9563-6b2e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-20 09:48:50*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,1.600000*%
G04 APERTURE END LIST*
D10*
%TO.C,X1*%
X-5200000Y-3400000D03*
X5200000Y-3400000D03*
%TD*%
M02*
